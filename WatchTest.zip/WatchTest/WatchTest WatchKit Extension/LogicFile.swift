//
//  LogicFile.swift
//  WatchTest WatchKit Extension
//
//  Created by Abita Shiney on 2019-03-14.
//  Copyright © 2019 Abita Shiney. All rights reserved.
//

import WatchKit

class LogicFile: WKInterfaceController {
  
    
}
