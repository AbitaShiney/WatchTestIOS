//
//  InterfaceController.swift
//  WatchTest WatchKit Extension
//
//  Created by Abita Shiney on 2019-03-14.
//  Copyright © 2019 Abita Shiney. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    @IBOutlet weak var image1: WKInterfaceImage!
    
    @IBOutlet weak var image2: WKInterfaceImage!
    
    @IBOutlet weak var image3: WKInterfaceImage!
    
    @IBOutlet weak var image4: WKInterfaceImage!
    
    @IBOutlet weak var myGroup: WKInterfaceGroup!
    
    @IBOutlet weak var WKTimer: WKInterfaceTimer!
    
   
    @IBOutlet weak var no1_btn: WKInterfaceButton!
    
    @IBOutlet weak var no2_btn: WKInterfaceButton!
    
    @IBOutlet weak var no3_btn: WKInterfaceButton!
    
    @IBOutlet weak var no4_btn: WKInterfaceButton!
    
    @IBOutlet weak var myGroup2: WKInterfaceGroup!
    
    @IBOutlet weak var livesLabel: WKInterfaceLabel!
    var myTimer : Timer?
    var elapsedTime : TimeInterval = 0.0
    var startTime = NSDate()
    var duration : TimeInterval = 4.0
    var ImageDict: [String:String] = [:]
   // var dictionary: [String: String] = [UIImage(named: “loading_1”)!: “firstpicture”, UIImage(named: “loading_2”)!: “secondpicture”, UIImage(named: “thirdpicture”)!: “thirdpicture”]
    
//   var imageDictionary = ["image1": UIImage(named: "loading_1"),
//    "image2": UIImage(named: "loading_2")]
    var Lives: Int!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        WKTimer.setDate(NSDate(timeIntervalSinceNow: duration) as Date)
        if(context != nil){
            Lives = context as! Int
        }
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        self.livesLabel.setText("Lives: \(Lives!)")
        let sharedPreferences = UserDefaults.standard
        var img = sharedPreferences.string(forKey: "image")
    
         var ImageDict = ["pic1" : "loading_1","pic2" : "loading_2","pic3" : "loading_3","pic4" : "loading_4"]
        
        for (key, value) in ImageDict{
            image1.setImage(UIImage(named: ImageDict["pic1"]!))
            image2.setImage(UIImage(named: ImageDict["pic2"]!))
            image3.setImage(UIImage(named: ImageDict["pic3"]!))
            image4.setImage(UIImage(named: ImageDict["pic4"]!))
        }
        Timer.scheduledTimer(timeInterval: duration, target: self, selector: #selector(ImgLogic), userInfo: nil, repeats: true)
        WKTimer.setDate(NSDate(timeIntervalSinceNow: duration) as Date)
        WKTimer.start()
     //   myGroup2.setHidden(true)
 
    }
    @objc func ImgLogic(){
        print("done")
        myGroup.setHidden(true)
        WKTimer.setHidden(true)
     //   myGroup2.setHidden(false)
        let backgroundImage1 = UIImage(named: "loading_2") as UIImage?
        self.no1_btn.setBackgroundImage(backgroundImage1)
        
        let backgroundImage2 = UIImage(named: "loading_3") as UIImage?
        self.no2_btn.setBackgroundImage(backgroundImage2)
        
        let backgroundImage3 = UIImage(named: "loading_4") as UIImage?
        self.no3_btn.setBackgroundImage(backgroundImage3)
        
        let backgroundImage4 = UIImage(named: "loading_1") as UIImage?
        self.no4_btn.setBackgroundImage(backgroundImage4)
    
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func btn1Clciked() {
        print("btn1 clciked")
        
        
      //  checkGame()
    }
    
    @IBAction func btn2Clicked() {
        print("btn2 clciked")
    }
    
    @IBAction func btn3Clicked() {
        print("btn3 clciked")
    }
    
    
    @IBAction func btn4Clicked() {
        print("btn4 clciked")
    }
    
//    func checkGame(){
//        var isWon = true
//
//        for (key, value) in ImageDict{
//
//            if(self.ImageDict[image1] == followButton.currentImage){
//                isWon = false
//            }
//
//
//        }
//    }
}
