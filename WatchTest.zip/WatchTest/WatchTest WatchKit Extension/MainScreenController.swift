//
//  MainScreenController.swift
//  WatchTest WatchKit Extension
//
//  Created by Abita Shiney on 2019-03-14.
//  Copyright © 2019 Abita Shiney. All rights reserved.
//

import UIKit
import WatchKit

class MainScreenController: WKInterfaceController {

    @IBOutlet weak var NameLabel: WKInterfaceLabel!
    
    override func willActivate() {
        super.willActivate()
        let sharedPreferences = UserDefaults.standard
        var Names = sharedPreferences.string(forKey: "name")
        
        // update the name
        self.NameLabel.setText("Hi \(sharedPreferences.string(forKey: "name")!)")
      
    }
    @IBAction func startBtn() {
       self.presentController(withName: "interfaceScreen", context: self)
       
    }
    
    @IBAction func btnEasy() {
        self.presentController(withName: "interfaceScreen", context: self)
       
    }
    
    @IBAction func btnHard() {
         self.presentController(withName: "interfaceScreen", context: self)
        
    }
}
