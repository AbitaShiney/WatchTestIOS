//
//  ViewController.swift
//  WatchTest
//
//  Created by Abita Shiney on 2019-03-14.
//  Copyright © 2019 Abita Shiney. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

